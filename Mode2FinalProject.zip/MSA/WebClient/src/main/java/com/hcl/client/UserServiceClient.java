package com.hcl.client;


public interface UserServiceClient {
	public User getUserByName(String name);
	
	public boolean knockOut(int civScore,int standardCivScore);

	public String registerUser(User user);
}
