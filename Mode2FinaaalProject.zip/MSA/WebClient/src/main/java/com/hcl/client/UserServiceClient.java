package com.hcl.client;


public interface UserServiceClient {
	public User getUserByName(String name);
	
	public boolean knockOut(ApplyLoan application);

	public String registerUser(User user);
}
