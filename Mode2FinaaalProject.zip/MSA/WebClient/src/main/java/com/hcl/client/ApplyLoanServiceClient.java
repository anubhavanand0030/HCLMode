package com.hcl.client;




public interface ApplyLoanServiceClient {
	public String applyLoan(ApplyLoan al);
	public int getAppId();
}
